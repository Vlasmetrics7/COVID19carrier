# install.packages("plm")     #library to estimated panel models
# install.packages("texreg")  #library of embelling tables

# LIBRARIES
library("plm")
library("texreg")
library("readxl")
library(stargazer)
library(lmtest)
library(dplyr)

# FOR COMPUTING ROBUST VARIANCES
vcovNW.pcce <- plm:::vcovNW.pcce

# reading data

#datapanel <- read_excel("Datos_Deaths_Pollution_Imputed.xlsx",sheet = "Hoja3")
dp15D <- read_excel("databasePM.xlsx",sheet = "15D")
dp10D <- read_excel("databasePM.xlsx",sheet = "10D")
dp7D <- read_excel("databasePM.xlsx",sheet = "7D")

###############################################

# PART 1: deaths vs PM10

panel15D<- cbind(dp15D$Date,dp15D$idx,dp15D$Casos,dp15D$Defunciones,dp15D$PM10)
panel10D<- cbind(dp10D$Date,dp10D$idx,dp10D$Casos,dp10D$Defunciones,dp10D$PM10)
panel7D<- cbind(dp7D$Date,dp7D$idx,dp7D$Casos,dp7D$Defunciones,dp7D$PM10)

ubpanel15D<-panel15D[complete.cases(panel15D), ]
ubpanel10D<-panel10D[complete.cases(panel10D), ]
ubpanel7D<-panel7D[complete.cases(panel7D), ]

date15D =ubpanel15D[,1]
idx15D=ubpanel15D[,2]
cases15D=ubpanel15D[,3]
death15D=ubpanel15D[,4]
pm1015D=ubpanel15D[,5]

date10D =ubpanel10D[,1]
idx10D=ubpanel10D[,2]
cases10D=ubpanel10D[,3]
death10D=ubpanel10D[,4]
pm1010D=ubpanel10D[,5]

date7D =ubpanel7D[,1]
idx7D=ubpanel7D[,2]
cases7D=ubpanel7D[,3]
death7D=ubpanel7D[,4]
pm107D=ubpanel7D[,5]

panel15D<-data.frame(date15D,idx15D,cases15D,death15D,pm1015D)
panel10D<-data.frame(date10D,idx10D,cases10D,death10D,pm1010D)
panel7D<-data.frame(date7D,idx7D,cases7D,death7D,pm107D)

Death15M1 <- pmg(death15D ~ pm1015D,data = panel15D, index = c("idx15D", "date15D"), model = c("cmg"),trend = FALSE)
Death10M1 <- pmg(death10D ~ pm1010D,data = panel10D, index = c("idx10D", "date10D"), model = c("cmg"),trend = FALSE)
Death7M1 <- pmg(death7D ~ pm107D,data = panel7D, index = c("idx7D", "date7D"), model = c("cmg"),trend = FALSE)

Case15M1 <- pmg(cases15D ~ pm1015D,data = panel15D, index = c("idx15D", "date15D"), model = c("cmg"),trend = FALSE)
Case10M1 <- pmg(cases10D ~ pm1010D,data = panel10D, index = c("idx10D", "date10D"), model = c("cmg"),trend = FALSE)
Case7M1 <- pmg(cases7D ~ pm107D,data = panel7D, index = c("idx7D", "date7D"), model = c("cmg"),trend = FALSE)


ccemgD15 <- pcce(death15D ~ pm1015D ,data = panel15D, index = c("idx15D", "date15D"), model = c("mg"),trend = FALSE)
ccemgD15.tab <- cbind(t(coeftest(ccemgD15, vcov = vcovNW)[,1:4]))
round(ccemgD15.tab, 3)

ccemgD15 <- pcce(cases15D ~ pm1015D ,data = panel15D, index = c("idx15D", "date15D"), model = c("mg"),trend = FALSE)
ccemgD15.tab <- cbind(t(coeftest(ccemgD15, vcov = vcovNW)[,1:4]))
round(ccemgD15.tab, 3)

ccemgD10 <- pcce(death10D ~ pm1010D ,data = panel10D, index = c("idx10D", "date10D"), model = c("mg"),trend = FALSE)
ccemgD10.tab <- cbind(t(coeftest(ccemgD10, vcov = vcovNW)[,1:4]))
round(ccemgD10.tab, 3)

ccemgD10 <- pcce(cases10D ~ pm1010D ,data = panel10D, index = c("idx10D", "date10D"), model = c("mg"),trend = FALSE)
ccemgD10.tab <- cbind(t(coeftest(ccemgD10, vcov = vcovNW)[,1:4]))
round(ccemgD10.tab, 3)

ccemgD7 <- pcce(death7D ~ pm107D ,data = panel7D, index = c("idx7D", "date7D"), model = c("mg"),trend = FALSE)
ccemgD7.tab <- cbind(t(coeftest(ccemgD7, vcov = vcovNW)[,1:4]))
round(ccemgD7.tab, 3)

ccemgD7 <- pcce(cases7D ~ pm107D ,data = panel7D, index = c("idx7D", "date7D"), model = c("mg"),trend = FALSE)
ccemgD7.tab <- cbind(t(coeftest(ccemgD7, vcov = vcovNW)[,1:4]))
round(ccemgD7.tab, 3)

###############################################

# PART 2: deaths vs PM25

panel15D<- cbind(dp15D$Date,dp15D$idx,dp15D$Casos,dp15D$Defunciones,dp15D$PM25)
panel10D<- cbind(dp10D$Date,dp10D$idx,dp10D$Casos,dp10D$Defunciones,dp10D$PM25)
panel7D<- cbind(dp7D$Date,dp7D$idx,dp7D$Casos,dp7D$Defunciones,dp7D$PM25)

ubpanel15D<-panel15D[complete.cases(panel15D), ]
ubpanel10D<-panel10D[complete.cases(panel10D), ]
ubpanel7D<-panel7D[complete.cases(panel7D), ]

date15D =ubpanel15D[,1]
idx15D=ubpanel15D[,2]
cases15D=ubpanel15D[,3]
death15D=ubpanel15D[,4]
pm2515D=ubpanel15D[,5]

date10D =ubpanel10D[,1]
idx10D=ubpanel10D[,2]
cases10D=ubpanel10D[,3]
death10D=ubpanel10D[,4]
pm2510D=ubpanel10D[,5]

date7D =ubpanel7D[,1]
idx7D=ubpanel7D[,2]
cases7D=ubpanel7D[,3]
death7D=ubpanel7D[,4]
pm257D=ubpanel7D[,5]

panel15D<-data.frame(date15D,idx15D,cases15D,death15D,pm2515D)
panel10D<-data.frame(date10D,idx10D,cases10D,death10D,pm2510D)
panel7D<-data.frame(date7D,idx7D,cases7D,death7D,pm257D)

Death15M2 <- pmg(death15D ~ pm2515D,data = panel15D, index = c("idx15D", "date15D"), model = c("cmg"),trend = FALSE)
Death10M2 <- pmg(death10D ~ pm2510D,data = panel10D, index = c("idx10D", "date10D"), model = c("cmg"),trend = FALSE)
Death7M2 <- pmg(death7D ~ pm257D,data = panel7D, index = c("idx7D", "date7D"), model = c("cmg"),trend = FALSE)

Case15M2 <- pmg(cases15D ~ pm2515D,data = panel15D, index = c("idx15D", "date15D"), model = c("cmg"),trend = FALSE)
Case10M2 <- pmg(cases10D ~ pm2510D,data = panel10D, index = c("idx10D", "date10D"), model = c("cmg"),trend = FALSE)
Case7M2 <- pmg(cases7D ~ pm257D,data = panel7D, index = c("idx7D", "date7D"), model = c("cmg"),trend = FALSE)





ccemgD15 <- pcce(death15D ~ pm2515D ,data = panel15D, index = c("idx15D", "date15D"), model = c("mg"),trend = FALSE)
ccemgD15.tab <- cbind(t(coeftest(ccemgD15, vcov = vcovNW)[,1:4]))
round(ccemgD15.tab, 3)

ccemgD15 <- pcce(cases15D ~ pm2515D ,data = panel15D, index = c("idx15D", "date15D"), model = c("mg"),trend = FALSE)
ccemgD15.tab <- cbind(t(coeftest(ccemgD15, vcov = vcovNW)[,1:4]))
round(ccemgD15.tab, 3)

ccemgD10 <- pcce(death10D ~ pm2510D ,data = panel10D, index = c("idx10D", "date10D"), model = c("mg"),trend = FALSE)
ccemgD10.tab <- cbind(t(coeftest(ccemgD10, vcov = vcovNW)[,1:4]))
round(ccemgD10.tab, 3)

ccemgD10 <- pcce(cases10D ~ pm2510D ,data = panel10D, index = c("idx10D", "date10D"), model = c("mg"),trend = FALSE)
ccemgD10.tab <- cbind(t(coeftest(ccemgD10, vcov = vcovNW)[,1:4]))
round(ccemgD10.tab, 3)

ccemgD7 <- pcce(death7D ~ pm257D ,data = panel7D, index = c("idx7D", "date7D"), model = c("mg"),trend = FALSE)
ccemgD7.tab <- cbind(t(coeftest(ccemgD7, vcov = vcovNW)[,1:4]))
round(ccemgD7.tab, 3)


ccemgD7 <- pcce(cases7D ~ pm257D ,data = panel7D, index = c("idx7D", "date7D"), model = c("mg"),trend = FALSE)
ccemgD7.tab <- cbind(t(coeftest(ccemgD7, vcov = vcovNW)[,1:4]))
round(ccemgD7.tab, 3)



###############################################

# PART 4: deaths vs ALL  MG

panel15D<- cbind(dp15D$Date,dp15D$idx,dp15D$Casos,dp15D$Defunciones,dp15D$PM10,dp15D$PM25)
panel10D<- cbind(dp10D$Date,dp10D$idx,dp10D$Casos,dp10D$Defunciones,dp15D$PM10,dp10D$PM25)
panel7D<- cbind(dp7D$Date,dp7D$idx,dp7D$Casos,dp7D$Defunciones,dp7D$PM10,dp7D$PM25)

ubpanel15D<-panel15D[complete.cases(panel15D), ]
ubpanel10D<-panel10D[complete.cases(panel10D), ]
ubpanel7D<-panel7D[complete.cases(panel7D), ]

date15D =ubpanel15D[,1]
idx15D=ubpanel15D[,2]
cases15D=ubpanel15D[,3]
death15D=ubpanel15D[,4]
pm1015D=ubpanel15D[,5]
pm2515D=ubpanel15D[,6]

date10D =ubpanel10D[,1]
idx10D=ubpanel10D[,2]
cases10D=ubpanel10D[,3]
death10D=ubpanel10D[,4]
pm1010D=ubpanel10D[,5]
pm2510D=ubpanel10D[,6]


date7D =ubpanel7D[,1]
idx7D=ubpanel7D[,2]
cases7D=ubpanel7D[,3]
death7D=ubpanel7D[,4]
pm107D=ubpanel7D[,5]
pm257D=ubpanel7D[,6]


panel15D<-data.frame(date15D,idx15D,cases15D,death15D,pm1015D,pm2515D)
panel10D<-data.frame(date10D,idx10D,cases10D,death10D,pm1010D,pm2510D)
panel7D<-data.frame(date7D,idx7D,cases7D,death7D,pm107D,pm257D)

Death15M3 <- pmg(death15D ~ pm1015D+pm2515D,data = panel15D, index = c("idx15D", "date15D"), model = c("cmg"),trend = FALSE,vcov = vcovNW)
Death10M3 <- pmg(death10D ~ pm1010D+pm2510D,data = panel10D, index = c("idx10D", "date10D"), model = c("cmg"),trend = FALSE,vcov = vcovNW)
Death7M3 <- pmg(death7D ~ pm107D+pm257D,data = panel7D, index = c("idx7D", "date7D"), model = c("cmg"),trend = FALSE,vcov = vcovNW)

Case15M3 <- pmg(cases15D ~ pm1015D+pm2515D,data = panel15D, index = c("idx15D", "date15D"), model = c("cmg"),trend = FALSE,vcov = vcovNW)
Case10M3 <- pmg(cases10D ~ pm1010D+pm2510D,data = panel10D, index = c("idx10D", "date10D"), model = c("cmg"),trend = FALSE,vcov = vcovNW)
Case7M3 <- pmg(cases7D ~ pm107D+pm257D,data = panel7D, index = c("idx7D", "date7D"), model = c("cmg"),trend = FALSE,vcov = vcovNW)




ccemgD15 <- pcce(death15D ~ pm1015D+pm2515D ,data = panel15D, index = c("idx15D", "date15D"), model = c("mg"),trend = FALSE)
ccemgD15.tab <- cbind(t(coeftest(ccemgD15, vcov = vcovNW)[,1:4]))
round(ccemgD15.tab, 3)

ccemgD15 <- pcce(cases15D ~ pm1015D+pm2515D ,data = panel15D, index = c("idx15D", "date15D"), model = c("mg"),trend = FALSE)
ccemgD15.tab <- cbind(t(coeftest(ccemgD15, vcov = vcovNW)[,1:4]))
round(ccemgD15.tab, 3)

ccemgD10 <- pcce(death10D ~ pm1010D+pm2510D ,data = panel10D, index = c("idx10D", "date10D"), model = c("mg"),trend = FALSE)
ccemgD10.tab <- cbind(t(coeftest(ccemgD10, vcov = vcovNW)[,1:4]))
round(ccemgD10.tab, 3)

ccemgD10 <- pcce(cases10D ~ pm1010D+pm2510D ,data = panel10D, index = c("idx10D", "date10D"), model = c("mg"),trend = FALSE)
ccemgD10.tab <- cbind(t(coeftest(ccemgD10, vcov = vcovNW)[,1:4]))
round(ccemgD10.tab, 3)

ccemgD7 <- pcce(death7D ~ pm107D+pm257D ,data = panel7D, index = c("idx7D", "date7D"), model = c("mg"),trend = FALSE)
ccemgD7.tab <- cbind(t(coeftest(ccemgD7, vcov = vcovNW)[,1:4]))
round(ccemgD7.tab, 3)

ccemgD7 <- pcce(cases7D ~ pm107D+pm257D ,data = panel7D, index = c("idx7D", "date7D"), model = c("mg"),trend = FALSE)
ccemgD7.tab <- cbind(t(coeftest(ccemgD7, vcov = vcovNW)[,1:4]))
round(ccemgD7.tab, 3)





###############################################

# PART 4: deaths vs ALL   CMG

Death15M0 <- pmg(death15D ~ pm1015D+pm2515D,data = panel15D, index = c("idx15D", "date15D"), model = c("mg"),trend = FALSE)
Death10M0 <- pmg(death10D ~ pm1010D+pm2510D,data = panel10D, index = c("idx10D", "date10D"), model = c("mg"),trend = FALSE)
Death7M0 <- pmg(death7D ~ pm107D+pm257D,data = panel7D, index = c("idx7D", "date7D"), model = c("mg"),trend = FALSE)

Case15M0 <- pmg(cases15D ~ pm1015D+pm2515D,data = panel15D, index = c("idx15D", "date15D"), model = c("mg"),trend = FALSE)
Case10M0 <- pmg(cases10D ~ pm1010D+pm2510D,data = panel10D, index = c("idx10D", "date10D"), model = c("mg"),trend = FALSE)
Case7M0 <- pmg(cases7D ~ pm107D+pm257D,data = panel7D, index = c("idx7D", "date7D"), model = c("mg"),trend = FALSE)


######################################
######################################
######################################

stargazer(Death15M0,Death15M1,Death15M2,Death15M3,Death15M3,Case15M0,Case15M1,Case15M2,Case15M3,Case15M3,
          type="text",title="An�lisis",
          align=TRUE, 
          column.labels=c("M0","M1","M2","M3","M4","M0","M1","M2","M3","M4"),
          omit.stat=c("LL","ser","f"), no.space=FALSE,single.row=FALSE)


stargazer(Death10M0,Death10M1,Death10M2,Death10M3,Death10M3,Case10M0,Case10M1,Case10M2,Case10M3,Case10M3,
          type="latex",title="An�lisis",
          align=TRUE, 
          column.labels=c("M0","M1","M2","M3","M4","M0","M1","M2","M3","M4"),
          omit.stat=c("LL","ser","f"), no.space=FALSE,single.row=FALSE)

stargazer(Death7M0,Death7M1,Death7M2,Death7M3,Death7M3,Case7M0,Case7M1,Case7M2,Case7M3,Case7M3,
          type="text",title="An�lisis",
          align=TRUE, 
          column.labels=c("M0","M1","M2","M3","M4","M0","M1","M2","M3","M4"),
          omit.stat=c("LL","ser","f"), no.space=FALSE,single.row=FALSE)


###########

ccemg1 <- pcce(death7D ~ pm107D+pm257D,data = panel7D, index = c("idx7D", "date7D"), model = c("mg"),trend = FALSE)
ccemg1.tab <- cbind(t(coeftest(ccemg1, vcov = vcovNW)[,1:4]))
round(ccemg1.tab, 3)

pcdtest(Death15M0,test = "rho")
pcdtest(Death15M3,test = "rho")
pcdtest(Case15M0,test = "rho")
pcdtest(Case15M3,test = "rho")

cipstest(resid(Death15M0), type="none")
cipstest(resid(Death15M3), type="none")
cipstest(resid(Case15M0), type="none")
cipstest(resid(Case15M3), type="none")

pcdtest(Death7M0,test = "rho")
pcdtest(Death7M2,test = "rho")
pcdtest(Case7M0,test = "rho")
pcdtest(Case7M2,test = "rho")

cipstest(resid(Death7M0), type="none")
cipstest(resid(Death7M3), type="none")
cipstest(resid(Case7M0), type="none")
cipstest(resid(Case7M3), type="none")

#############

pbgtest(Death15M0,order=4)
pbgtest(Death15M3,order=4)
pbgtest(Case15M0,order=4)
pbgtest(Case15M3,order=4)

pbgtest(Death7M0,order=4)
pbgtest(Death7M3,order=4)
pbgtest(Case7M0,order=4)
pbgtest(Case7M3,order=4)

