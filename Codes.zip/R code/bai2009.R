library("plm")
library("texreg")
library("readxl")
library(stargazer)
library(lmtest)
library(dplyr)
library("phtt")

# FOR COMPUTING ROBUST VARIANCES
vcovNW.pcce <- plm:::vcovNW.pcce

# reading data

dp15D <- read_excel("databasePM.xlsx",sheet = "15DBAI")
dp7D <- read_excel("databasePM.xlsx",sheet = "7DBAI")

panel15D<- cbind(dp15D$Date,dp15D$idx,dp15D$Casos,dp15D$Defunciones,dp15D$PM10,dp15D$PM25)
panel7D<- cbind(dp7D$Date,dp7D$idx,dp7D$Casos,dp7D$Defunciones,dp7D$PM10,dp7D$PM25)

ubpanel15D<-panel15D[complete.cases(panel15D), ]
ubpanel7D<-panel7D[complete.cases(panel7D), ]

date15D =ubpanel15D[,1]
idx15D=ubpanel15D[,2]
cases15D=ubpanel15D[,3]
death15D=ubpanel15D[,4]
pm1015D=ubpanel15D[,5]
pm2515D=ubpanel15D[,6]

date7D =ubpanel7D[,1]
idx7D=ubpanel7D[,2]
cases7D=ubpanel7D[,3]
death7D=ubpanel7D[,4]
pm107D=ubpanel7D[,5]
pm257D=ubpanel7D[,6]

panel15D<-data.frame(date15D,idx15D,cases15D,death15D,pm1015D,pm2515D)
panel7D<-data.frame(date7D,idx7D,cases7D,death7D,pm107D,pm257D)

############

N <- 9
T <- 122
## Dependent variable:
Cases <- matrix(panel15D$cases15D, T, N)
death<- matrix(panel15D$death15D, T, N)
## Independent variables:
pm25<- matrix(panel15D$pm2515D, T, N)
pm10<- matrix(panel15D$pm1015D, T, N)

panel15D.KSS <- KSS(formula = death ~ pm10+pm25) 
(panel15D.KSS.summary <- summary(panel15D.KSS))

(panel15D.Eup.None <- Eup(death ~ pm25+pm10,additive.effects = "none",dim.criterion = "BIC",d.max = 1))

(panel15D.Eup.Time <- Eup(death ~ pm25+pm10,additive.effects = "time",dim.criterion = "BIC",d.max = 2))
summary(panel15D.Eup.Time)

(panel15D.Eup.Ind <- Eup(death ~ pm25+pm10,additive.effects = "individual",dim.criterion = "BIC",d.max = 2))
summary(panel15D.Eup.Ind)

(panel15D.Eup.TW <- Eup(death ~ pm25+pm10,additive.effects = "twoways",dim.criterion = "PC1",d.max = 1))
summary(panel15D.Eup.TW)
coef(summary(panel15D.Eup.TW))
#plot(summary(panel15D.Eup))

Obj1 <- Eup(death ~ pm25+pm10,additive.effects = "twoways",factor.dim = 2)
checkSpecif(Obj1, level = 0.05)

(panel15D.Eup.TW <- Eup(Cases ~ pm25+pm10,additive.effects = "twoways",dim.criterion = "PC1",d.max = 1))
summary(panel15D.Eup.TW)
coef(summary(panel15D.Eup.TW))
#plot(summary(panel15D.Eup))

Obj1 <- Eup(Cases ~ pm25+pm10,additive.effects = "twoways",factor.dim = 2)
checkSpecif(Obj1, level = 0.05)


######## 7 DAYS ###############

############

N <- 9
T <- 130
## Dependent variable:
Cases <- matrix(panel7D$cases7D, T, N)
death<- matrix(panel7D$death7D, T, N)
## Independent variables:
pm25<- matrix(panel7D$pm257D, T, N)
pm10<- matrix(panel7D$pm107D, T, N)

(panel7D.Eup.None <- Eup(death ~ pm25+pm10,additive.effects = "none",dim.criterion = "BIC",d.max = 1))

(panel7D.Eup.Time <- Eup(death ~ pm25+pm10,additive.effects = "time",dim.criterion = "BIC",d.max = 2))
summary(panel7D.Eup.Time)

(panel7D.Eup.Ind <- Eup(death ~ pm25+pm10,additive.effects = "individual",dim.criterion = "BIC",d.max = 2))
summary(panel7D.Eup.Ind)

(panel7D.Eup.TW <- Eup(death ~ pm25+pm10,additive.effects = "twoways",dim.criterion = "PC1",d.max = 2))
summary(panel7D.Eup.TW)
coef(summary(panel7D.Eup.TW))
#plot(summary(panel15D.Eup))

Obj1 <- Eup(death ~ pm25+pm10,additive.effects = "twoways",factor.dim = 2)
checkSpecif(Obj1, level = 0.05)

panel15D.Eup.TW <- Eup(Cases ~ pm25+pm10,additive.effects = "twoways",dim.criterion = "PC1",d.max = 1)
summary(panel15D.Eup.TW)
coef(summary(panel15D.Eup.TW))
#plot(summary(panel15D.Eup))

Obj1 <- Eup(Cases ~ pm25+pm10,additive.effects = "twoways",factor.dim = 2)
checkSpecif(Obj1, level = 0.05)













