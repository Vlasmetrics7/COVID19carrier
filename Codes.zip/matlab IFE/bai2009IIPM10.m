function R=bai2009IIPM10

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
opts = spreadsheetImportOptions("NumVariables", 7);
opts.Sheet = "10DBAI";
opts.DataRange = "A2:G1144";
opts.VariableNames = ["Date", "Alcaldia", "idx", "Casos","Defunciones", "PM10", "PM25"];
opts.VariableTypes = ["double", "double", "double", "double", "double", "double", "double"];
dataBAI2009S5 = readtable("databasePM.xlsx", opts, "UseExcel", false);
Xdata = table2array(dataBAI2009S5);
clear opts

PM10=reshape(Xdata(:,6),127,9);
PM25=reshape(Xdata(:,7),127,9);
dead=reshape(Xdata(:,5),127,9);
cases=reshape(Xdata(:,4),127,9);
XX(:,:,1)=ones(127,9);
XX(:,:,2)=PM10;
XX(:,:,3)=PM25;
X=XX;
Y=dead;
%Y=cases;

[T,N]=size(Y);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
niter=1; 
maxiter=10;  % maximum number of iterations  (set to 1000) 
BETA=zeros(maxiter, 1); % contains the ``within", infeasible, the Interative effects, and the naive estimators
SIGMA=zeros(maxiter);
NNN=zeros(maxiter);   % the number of iterations to achieve convergence 
grandmean=zeros(maxiter,1);
p=3;    % number of regressors 

BETA2=zeros(maxiter, 10);
  
   for  niter=1:maxiter
    r=1;
    p=3;

    MFF=zeros(T,T,3);    % to contain three projection matrices
MLL=zeros(N,N,3);
Beta0=zeros(p,3);    % to contain three different estimates
 
if niter==1
    [beta0]=Mul_panelbeta(X,Y,eye(127));  % naive estimator (also used as a starting value)
else 
    [beta0]=Mul_panelbeta(X,Y,cov(e1'));  % naive estimator (also used as a starting value)
end
        
    BETA2(niter, 1:p)=beta0';    % ols estimator
    U=Y;
    for k=1:p;
        U=U-X(:,:,k)*beta0(k);
    end
    
    [F1,L1,VNT]=panelFactorNew(U,r); 
    
    beta=zeros(p,3);    % to contain the interative effect estimators, with different staring methods (3 methods)
    nnn=zeros(1,3);   % contain the number of iterations for the three methods to achieve convergence
    sigma2=zeros(1,3); % the estimated residual variance for each starting method, also the optimal value of the objective function
   
     [XXinv]= Mul_XXinv(X);   % outside the beta iteration loop
          [beta(:,1), F1,L1, VNT, e1, nnn(1)]=Mul_betaIterNew(X,XXinv, Y, F1,L1, r, 0.1);
          sigma2(:,1)=trace(e1*e1')/(N*T-r*(N+T)+r^2-2);
          
          for i=1:9
              XMM=[X(:,i,1),X(:,i,2),X(:,i,3)];
           se = NeweyWest(e1(:,i),XMM,0); estand(:,i)=se;
          end
    
       BETA(niter,1:p)=beta(:,1)';    % the interactive effects estimator
       NNN(niter)=nnn(1);
       SIGMA(niter)=sigma2(:,1);
    
   
end  % niter loop


%save('Mul_BETA', 'BETA');
%save('Mul_NNN', 'NNN');
%save('Mul_SIGMA', 'SIGMA');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
   
R.BETA=BETA;
R.sigma=estand;
R.L=L1;
R.F=F1;

figure(2)
barh(sort(L1))
   
    
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 